<script defer src="../public/jquery/jquery-3.6.0.min.js"></script>
<script defer src="../public/bootstrap/bootstrap.min.js"></script>
<script defer src="../public/bootstrap/popper.min.js"></script>
<script defer src="../public/datatable/jquery.dataTables.min.js"></script>
<script defer src="../public/datatable/dataTables.bootstrap4.min.js"></script>
<script defer src="../public/datatable/dataTables.responsive.min.js"></script>
<script defer src="../public/datatable/responsive.bootstrap4.min.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script defer src="../public/sweetalert2/sweetalert2@11.js"></script>

<script defer src="../public/js/usuarios/usuarios.js"></script>
<script defer src="../public/js/asignacion/asignacion.js"></script>
<script defer src="../public/js/inicio/actualizarPersonales.js"></script>

<!-- seccion de  botones de datatable -->
<script defer src="../public/datatable/dataTables.buttons.min.js"></script>
<script defer src="../public/datatable/jszip.min.js"></script>
<script defer src="../public/datatable/pdfmake.min.js"></script>
<script defer src="../public/datatable/vfs_fonts.js"></script>
<script defer src="../public/datatable/buttons.html5.min.js"></script>
</body>

</html>